/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mrahcafe;

import java.io.Serializable;

/**
 *
 * @author HoMe
 */
public class Reservations implements Serializable
{
    private String name;
    private int phon_number;
    private String time;
    private String pm_am;

    public Reservations(String name, int phon_number, String time, String pm_am) {
        this.name = name;
        this.phon_number = phon_number;
        this.time = time;
        this.pm_am = pm_am;
    }

    Reservations(String name, String phone) 
    {
      this.name = name;
      this.phon_number = phon_number;
    }

    public String getName() {
        return name;
    }

    public int getPhon_number() {
        return phon_number;
    }

    public String getTime() {
        return time;
    }

    public String getPm_am() {
        return pm_am;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhon_number(int phon_number) {
        this.phon_number = phon_number;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setPm_am(String pm_am) {
        this.pm_am = pm_am;
    }
    
}
