package mrahcafe;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;

public class IceCoffesController 
{
    Double ColdBrewINF= 17.0;
    Double mochaINF= 18.0;
    Double latteINF= 20.0;
    Double SpanishINF= 25.0;
    Double FrappuccinoINF = 20.0;
    Double ICEcost = 0.0;


    @FXML
    private Button ice_Cancel_but;

    @FXML
    private Button ice_next_but;

    @FXML
    private RadioButton Frappuccino;

    @FXML
    private RadioButton ridSpanishLatte;

    @FXML
    private RadioButton radIcemocha;
    @FXML
    private RadioButton brrrrreeeeewww;
    @FXML
    private RadioButton radIcelatte;

    void AboutAction(ActionEvent event) {

    }

    void ReportAction(ActionEvent event) {

    }

    void Suggestionsa_complaintsAction(ActionEvent event) 
    {

    }

    void about_usAction(ActionEvent event) 
    {

    }

    @FXML
    void ice_Cancel_butAction(ActionEvent event) 
    {
        /*
        
        */
        
        try {
           
            FXMLLoader loader = new FXMLLoader(getClass().getResource("HotCoffes.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    void ice_next_butAction(ActionEvent event) 
    {
    /*
    
    Double latteINF= 20.0;
    
    private RadioButton radIcelatte;
    */
  String icetype=null;        
        if (Frappuccino.isSelected())
        {
           ICEcost = FrappuccinoINF ;
           icetype = " Frappuccino "; 
        }
        else if (ridSpanishLatte.isSelected())
        {
            ICEcost =SpanishINF;
            icetype = " SpanishLatte "; 
        }
        else if (radIcemocha.isSelected())
        {
            ICEcost = mochaINF;
            icetype = " Ice mocha "; 
        }
        else if (brrrrreeeeewww.isSelected())
        {
            ICEcost = ColdBrewINF;
            icetype = " Cold Brew "; 
        }
        else if (radIcelatte.isSelected())
        {
            ICEcost = latteINF;
            icetype = " Ice latte "; 
        }
        
         System.out.println(ICEcost); // only to chick if it is work will
        
          try 
          {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ConfirmPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            ConfirmPageController ConfirmCONTROLAR = loader.getController();
            ConfirmCONTROLAR.setUserData(icetype,ICEcost);
           } 
           catch (IOException io) 
           {
            System.out.println("FXML Loading Error");
           }

    }

    void working_hoursAction(ActionEvent event)
    {

    }

    @FXML
    private void FrappuccinoAction(ActionEvent event) 
    {
        
    }

}
