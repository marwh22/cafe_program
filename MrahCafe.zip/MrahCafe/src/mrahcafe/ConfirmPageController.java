/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mrahcafe;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author HoMe
 */
public class ConfirmPageController implements Initializable {

    @FXML
    private Button Confirm;
    @FXML
    private TextField Nametext;
    @FXML
    private TextField phontext;
    @FXML
    private TextField hour;
    @FXML
    private TextField ampm;
    @FXML
    private TextField placrr;
    @FXML
    private TextField hottext;
    @FXML
    private TextField icetext;
    @FXML
    private Button Confirm1;
    @FXML
    private Label price;
    @FXML
    private TextField priceplace;
    @FXML
    private Label hotprice;
    @FXML
    private TextField pricehot;
    @FXML
    private TextField iceprice;
    @FXML
    private TextField finel;
    
    Reservations ReservationsUser;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ConfirmAction(ActionEvent event) 
    
    {
        writeToFile(ReservationsUser);
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("LAST.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        }
        catch (IOException io) 
        {
            System.out.println("FXML Loading Error");
        }
    }

    void setUserData(String name, String phone) 
    {
        ReservationsUser = new Reservations (name,phone);
        Nametext.setText(name);
        Nametext.setText(phone);
    }

    void setUserData(String Userplace, String UserAM_PM, String value) 
    {
       
    }

    void setUserData(String hottype, int hotusercost) 
    {
       
    }

    void setUserData(String icetype, Double ICEcost)
    {
       
    }

    private void writeToFile(Object og) 
    {
        ObjectOutputStream objectOutputFile = null;
        FileOutputStream outStream = null;
        
        try 
        {
           outStream = new FileOutputStream ("Reservations.txt");
           objectOutputFile = new ObjectOutputStream (outStream);
           objectOutputFile.writeObject(og);
           System.out.print("custmer inf add in file ");
        }
       catch(FileNotFoundException ex)
        {
            ex.getMessage();  
        }
        catch(IOException ex)
        {
             ex.getMessage();        
        }
        
        
    }
    
}
