package mrahcafe;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class HotCoffesController implements Initializable{
     
    Double espressoINF= 17.0;
    Double AmericanoINF= 18.0;
    Double cappuccinoINF= 20.0;
    Double CortadoINF= 25.0;
    Double latteINF = 20.0;
    Double HOTcost = 0.0;
    

    @FXML
    private Button HOT_NEXT;

    @FXML
    private Label LABAmericano;

    @FXML
    private Label LABCortado;

    @FXML
    private Label LABHotCoffee;

    @FXML
    private Label LABcappuccino;

    @FXML
    private Label LABespresso;

    @FXML
    private Label LABlatte;


    @FXML // fx:id="espresso"
    private RadioButton espresso; // Value injected by FXMLLoader

    @FXML // fx:id="hot_orderGroup"
    private ToggleGroup hot_orderGroup; // Value injected by FXMLLoader

    @FXML // fx:id="Americano"
    private RadioButton Americano; // Value injected by FXMLLoader

    @FXML // fx:id="cappuccino"
    private RadioButton cappuccino; // Value injected by FXMLLoader

    @FXML // fx:id="Cortado"
    private RadioButton Cortado; // Value injected by FXMLLoader

    @FXML // fx:id="latte"
    private RadioButton latte; // Value injected by FXMLLoader


    @FXML
    private Button hotCancel;



    void AboutAction(ActionEvent event) {

    }

    @FXML
    void AmericanoAction(ActionEvent event) {

    }

    @FXML
    void CortadoAction(ActionEvent event) {

    }

    @FXML
    void HOT_NEXTAction(ActionEvent event)
    {
 String hottype=null;
        
        if (espresso.isSelected())
        {
            HOTcost = espressoINF;
            hottype = "espresso";
        }
        else if (Americano.isSelected())
        {
            HOTcost = AmericanoINF;
            hottype = "Americano";
        }
        else if (cappuccino.isSelected())
        {
            HOTcost = cappuccinoINF;
            hottype = "cappuccino";
        }
        else if (Cortado.isSelected())
        {
            HOTcost = CortadoINF;
              hottype = "Cortado"; 
        }
        else if (latte.isSelected())
        {
            HOTcost = latteINF;
             hottype = "latte";
        }
        int hotusercost = 0;
        
         System.out.println(HOTcost); // only to chick if it is work will
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("IceCoffes.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            
            ConfirmPageController ConfirmCONTROLAR = loader.getController();
            ConfirmCONTROLAR.setUserData(hottype,hotusercost);

        } 
        catch (IOException io)
        {
            System.out.println("FXML Loading Error");
        }
    }

    void ReportAction(ActionEvent event) {

    }

    void Suggestionsa_complaintsAction(ActionEvent event) {

    }

    void about_usAction(ActionEvent event) {

    }

    void cappuccinoAcion(ActionEvent event) {

    }

    @FXML
    void espressoAction(ActionEvent event) {

    }

    @FXML
    void hotCancelAction(ActionEvent event) {
     /*   
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SecondPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }*/
    }

    @FXML
    void latteAction(ActionEvent event) {

    }

    void working_hoursAction(ActionEvent event) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       
    }

    @FXML
    private void cappuccinoAction(ActionEvent event) {
    }

}
