/**
 * Sample Skeleton for 'SecondPage.fxml' Controller Class
 */

package mrahcafe;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class SecondPageController implements Initializable
{
    Double REST  = 40.0;
    Double STRET = 30.0;
    Double STUDY = 20.0;
    Double cost  = 0.0;
    

    @FXML // fx:id="choosePlace"
    private Label choosePlace; // Value injected by FXMLLoader

    @FXML // fx:id="detailsLink"
    private Hyperlink detailsLink; // Value injected by FXMLLoader

    @FXML // fx:id="moredetalsLab"
    private Label moredetalsLab; // Value injected by FXMLLoader

    @FXML // fx:id="choostime"
    private Label choostime; // Value injected by FXMLLoader

    @FXML // fx:id="timecom"
    private ComboBox<String> timecom; // Value injected by FXMLLoader

    @FXML // fx:id="sac_cancel"
    private Button sac_cancel; // Value injected by FXMLLoader

    @FXML // fx:id="sac_next"
    private Button sac_next; // Value injected by FXMLLoader

    @FXML // fx:id="rad_study"
    private RadioButton rad_study; // Value injected by FXMLLoader

    @FXML // fx:id="placeGrupe"
    private ToggleGroup placeGrupe; // Value injected by FXMLLoader

    @FXML // fx:id="rad_rest"
    private RadioButton rad_rest; // Value injected by FXMLLoader

    @FXML // fx:id="rad_steet"
    private RadioButton rad_steet; // Value injected by FXMLLoader

    @FXML // fx:id="studylroomLab"
    private Label studylroomLab; // Value injected by FXMLLoader

    @FXML // fx:id="streetwindowLab"
    private Label streetwindowLab; // Value injected by FXMLLoader

    @FXML // fx:id="resttimeLab"
    private Label resttimeLab; // Value injected by FXMLLoader
    private MenuBar menubarbar; // Value injected by FXMLLoader
    private Menu menumenu; // Value injected by FXMLLoader
    private Menu Aboutmenu; // Value injected by FXMLLoader
    private MenuItem about_us; // Value injected by FXMLLoader
    private MenuItem working_hours; // Value injected by FXMLLoader
    private Menu Suggestionsa_complaints; // Value injected by FXMLLoader
    private MenuItem Report; // Value injected by FXMLLoader

    @FXML // fx:id="AM"
    private CheckBox AM; // Value injected by FXMLLoader

    @FXML // fx:id="PM"
    private CheckBox PM; // Value injected by FXMLLoader

    
    

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        timecom.getItems().addAll("7","8","9","10","11","12");
    } 
    
    void AboutAction(ActionEvent event) {

    }

    void ReportAction(ActionEvent event) {

    }

    void Suggestionsa_complaintsAction(ActionEvent event) {

    }

    void about_usAction(ActionEvent event) {

    }


    @FXML
    void sac_cancelAction(ActionEvent event) 
    {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MrahCafe.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    void sac_nextAction(ActionEvent event) 
    { 
        String Userplace = null;
        String UserAM_PM = null;
        if (!Validitionradio()&&!Validitiontextbox()&& Validitioncombo())
        {
         JOptionPane.showMessageDialog(null, " You must choose the place and time "
                 + "\n    to complete the reservation",
      "wrong input", JOptionPane.ERROR_MESSAGE);
        }
         else if (!Validitionradio())
        {
         JOptionPane.showMessageDialog(null, " You must choose the\" PLACE \""
                 + "\n     to complete the reservation",
      "wrong input", JOptionPane.ERROR_MESSAGE);
        }
          else if (Validitioncombo())
        {
         JOptionPane.showMessageDialog(null, " You must choose the\" TIME \""
                 + "\n     to complete the reservation",
      "wrong input", JOptionPane.ERROR_MESSAGE);
        }
         else if (!Validitiontextbox())
        {
         JOptionPane.showMessageDialog(null, " Please choose \"DAY ( A.M.)\"or \"NIGHT( P.M.)\""
                 + "\n     to complete the reservation",
      "wrong input", JOptionPane.ERROR_MESSAGE);
        }
           
        
        else
        {
       
        
        if (rad_rest.isSelected())
        {
            cost = REST;
            Userplace = "rest time";
        }
        else if (rad_steet.isSelected())
        {
            cost = STRET;
            Userplace = "street window";
        }
        else if (rad_study.isSelected())
        {
            cost = STUDY;
            Userplace = "study room";
        }
        System.out.println(cost); // only to chick if it is work will
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("HotCoffes.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            
            ConfirmPageController ConfirmCONTROLAR = loader.getController();
             if (AM.isSelected())
            {
              UserAM_PM = "A.M.";
            }
             else
            {
              UserAM_PM = "P.M.";  
            }
           System.out.println(Userplace); // only to chick if it is work will
           System.out.println(UserAM_PM); // only to chick if it is work will
           System.out.println(timecom.getValue()); // only to chick if it is work will
           ConfirmCONTROLAR.setUserData(Userplace,UserAM_PM,timecom.getValue());
          
        } 
        catch (IOException io) 
        {
            System.out.println("FXML Loading Error");
        }
    }
    }

    public boolean Validitionradio() 
    {
        return rad_rest.isSelected()||rad_steet.isSelected()||rad_study.isSelected();
    } 
    public boolean Validitiontextbox() 
    {
        return AM.isSelected()||PM.isSelected();
    } 
    public boolean Validitioncombo() 
    {
        return timecom.getValue() == null || timecom.getValue().equals("");
    } 
    
    @FXML
    void timecomAction(ActionEvent event) 
    {
  
    }

    void working_hoursAction(ActionEvent event)
    {

    }

    void initialize() {
        assert choosePlace != null : "fx:id=\"choosePlace\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert detailsLink != null : "fx:id=\"detailsLink\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert moredetalsLab != null : "fx:id=\"moredetalsLab\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert choostime != null : "fx:id=\"choostime\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert timecom != null : "fx:id=\"timecom\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert sac_cancel != null : "fx:id=\"sac_cancel\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert sac_next != null : "fx:id=\"sac_next\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert rad_study != null : "fx:id=\"rad_study\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert placeGrupe != null : "fx:id=\"placeGrupe\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert rad_rest != null : "fx:id=\"rad_rest\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert rad_steet != null : "fx:id=\"rad_steet\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert studylroomLab != null : "fx:id=\"studylroomLab\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert streetwindowLab != null : "fx:id=\"streetwindowLab\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert resttimeLab != null : "fx:id=\"resttimeLab\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert menubarbar != null : "fx:id=\"menubarbar\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert menumenu != null : "fx:id=\"menumenu\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert Aboutmenu != null : "fx:id=\"Aboutmenu\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert about_us != null : "fx:id=\"about_us\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert working_hours != null : "fx:id=\"working_hours\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert Suggestionsa_complaints != null : "fx:id=\"Suggestionsa_complaints\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert Report != null : "fx:id=\"Report\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert AM != null : "fx:id=\"AM\" was not injected: check your FXML file 'SecondPage.fxml'.";
        assert PM != null : "fx:id=\"PM\" was not injected: check your FXML file 'SecondPage.fxml'.";

    }
}
