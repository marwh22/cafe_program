/**
 * Sample Skeleton for 'MrahCafe.fxml' Controller Class
 */

package mrahcafe;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class MrahCafeController {


    @FXML // fx:id="label_phon"
    private Label label_phon; // Value injected by FXMLLoader

    @FXML // fx:id="name_text"
    private TextField name_text; // Value injected by FXMLLoader

    @FXML // fx:id="label_name"
    private Label label_name; // Value injected by FXMLLoader

    @FXML // fx:id="phon_text"
    private TextField phon_text; // Value injected by FXMLLoader

    @FXML // fx:id="label_thefolo"
    private Label label_thefolo; // Value injected by FXMLLoader

    @FXML // fx:id="label_welcome"
    private Label label_welcome; // Value injected by FXMLLoader

    @FXML // fx:id="labl_for"
    private Label labl_for; // Value injected by FXMLLoader

    @FXML // fx:id="f_close"
    private Button f_close; // Value injected by FXMLLoader

    @FXML // fx:id="f_order"
    private Button f_order; // Value injected by FXMLLoader

    @FXML // fx:id="menubarbar"
    private MenuBar menubarbar; // Value injected by FXMLLoader

    @FXML // fx:id="menumenu"
    private Menu menumenu; // Value injected by FXMLLoader

    @FXML // fx:id="Aboutmenu"
    private Menu Aboutmenu; // Value injected by FXMLLoader
    private Button aboutbouton; // Value injected by FXMLLoader

    @FXML // fx:id="Suggestionsa_complaints"
    private Menu Suggestionsa_complaints; // Value injected by FXMLLoader
    private Button sgeandcomp; // Value injected by FXMLLoader
    @FXML
    private MenuItem about_us;
    @FXML
    private MenuItem working_hours;
    @FXML
    private MenuItem Report;

    @FXML
    void AboutAction(ActionEvent event) 
    {
    }

    @FXML
    void Suggestionsa_complaintsAction(ActionEvent event) {

    }

    @FXML
    void f_CloseAction(ActionEvent event)
    {
     System.exit(0);
    }

    @FXML
    void f_OrderAction(ActionEvent event) 
    {
        
    if (name_text.getText().isEmpty()||!(name_text.getText().matches("([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)")))
        {
         JOptionPane.showMessageDialog(null, " Please enter the name correctly !",
      "wrong input", JOptionPane.ERROR_MESSAGE);
        }
        if (phon_text.getText().isEmpty()||!(phon_text.getText().matches("(05)[0-9]{8}")))
        {
         JOptionPane.showMessageDialog(null, "   Please Enter the number correctly!     "
                 + "\n     10 numbers starting with 05 \n         Example: 0506257983",
      "wrong input", JOptionPane.ERROR_MESSAGE);
        }
        else
        {
        try
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SecondPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            
            ConfirmPageController ConfirmCONTROLAR = loader.getController();
            
         ConfirmCONTROLAR.setUserData(name_text.getText(),phon_text.getText());
          
        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
        
    }
    }

    @FXML
    void nametextAction(ActionEvent event) {

    }

    @FXML
    void phonetextAction(ActionEvent event) {

    }

    void sgeandcompaction(ActionEvent event) {

    }

    void togotoabout(ActionEvent event)  
    {
        
    }

    void initialize() {
        assert label_phon != null : "fx:id=\"label_phon\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert name_text != null : "fx:id=\"name_text\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert label_name != null : "fx:id=\"label_name\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert phon_text != null : "fx:id=\"phon_text\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert label_thefolo != null : "fx:id=\"label_thefolo\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert label_welcome != null : "fx:id=\"label_welcome\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert labl_for != null : "fx:id=\"labl_for\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert f_close != null : "fx:id=\"f_close\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert f_order != null : "fx:id=\"f_order\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert menubarbar != null : "fx:id=\"menubarbar\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert menumenu != null : "fx:id=\"menumenu\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert Aboutmenu != null : "fx:id=\"Aboutmenu\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert aboutbouton != null : "fx:id=\"aboutbouton\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert Suggestionsa_complaints != null : "fx:id=\"Suggestionsa_complaints\" was not injected: check your FXML file 'MrahCafe.fxml'.";
        assert sgeandcomp != null : "fx:id=\"sgeandcomp\" was not injected: check your FXML file 'MrahCafe.fxml'.";

    }

    @FXML
    private void about_usAction(ActionEvent event) 
    {
        
        try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AboutUsController.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        } 
        catch (IOException io) 
        {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void working_hoursAction(ActionEvent event) 
    {
          /*try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AboutUsController.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        } 
        catch (IOException io) 
        {
            System.out.println("FXML Loading Error");
        }*/
       
    }

    @FXML
    private void ReportAction(ActionEvent event) 
    {
         /* try 
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AboutUsController.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        } 
        catch (IOException io) 
        {
            System.out.println("FXML Loading Error");
        }*/
    }
}
